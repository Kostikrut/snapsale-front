function Favorites() {
  return <div></div>;
}

export default Favorites;
