import React, { useState, useEffect } from "react";
import "../pages/styles/MenageBanners.css";

const MenageBanners = () => {
  const [banners, setBanners] = useState([]);
  const [formData, setFormData] = useState({
    title: "",
    link: "",
    isActive: true,
    image: null,
  });
  const [editingBanner, setEditingBanner] = useState(null);

  useEffect(() => {
    fetchBanners();
  }, []);

  const fetchBanners = async () => {
    try {
      const response = await fetch("/api/banners");
      const data = await response.json();
      setBanners(data.data.banners);
    } catch (error) {
      console.error("Error fetching banners", error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]:
        type === "file" ? files[0] : type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const form = new FormData();
    for (const key in formData) {
      form.append(key, formData[key]);
    }

    try {
      const options = {
        method: editingBanner ? "PATCH" : "POST",
        body: form,
      };
      const url = editingBanner
        ? `/api/banners/${editingBanner._id}`
        : "/api/banners";
      await fetch(url, options);
      setFormData({ title: "", link: "", isActive: true, image: null });
      setEditingBanner(null);
      fetchBanners();
    } catch (error) {
      console.error("Error saving banner", error);
    }
  };

  const handleEdit = (banner) => {
    setEditingBanner(banner);
    setFormData({ ...banner, image: null });
  };

  const handleDelete = async (id) => {
    try {
      await fetch(`/api/banners/${id}`, { method: "DELETE" });
      fetchBanners();
    } catch (error) {
      console.error("Error deleting banner", error);
    }
  };

  return (
    <div className="banner-crud-container">
      <h1>Manage Banners</h1>
      <form onSubmit={handleSubmit} className="banner-form">
        <input
          type="text"
          name="title"
          placeholder="Title"
          value={formData.title}
          onChange={handleInputChange}
          required
        />
        <input
          type="text"
          name="link"
          placeholder="Link"
          value={formData.link}
          onChange={handleInputChange}
          required
        />
        <input
          type="file"
          name="image"
          accept="image/*"
          onChange={handleInputChange}
          required={!editingBanner}
        />
        <label>
          Active:
          <input
            type="checkbox"
            name="isActive"
            checked={formData.isActive}
            onChange={handleInputChange}
          />
        </label>
        <button type="submit">
          {editingBanner ? "Update" : "Create"} Banner
        </button>
      </form>

      <ul className="banner-list">
        {banners.map((banner) => (
          <li key={banner._id} className="banner-item">
            <img src={banner.image.url} alt={banner.title} />
            <h3>{banner.title}</h3>
            <p>Link: {banner.link}</p>
            <p>Active: {banner.isActive ? "Yes" : "No"}</p>
            <button onClick={() => handleEdit(banner)}>Edit</button>
            <button onClick={() => handleDelete(banner._id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MenageBanners;
